package kr.mjc.minbeom.java.exceptions;

public class Num {
    public static void main(String[] args) {
        
    }

}
