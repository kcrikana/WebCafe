package kr.mjc.minbeom.java.jdbc.article;

import lombok.Data;

@Data
public class Article {
    int articleId;
    String title;
    String content;
    int userId;
    String name;
    String cdate;
    String udate;

    @Override
    public String toString() {
        return "Article{" + "articleId=" + articleId + ", userId='" + userId + '\''
                + ", title='" + title + '\'' + ", content='" + content + '\'' + '}';
    }


}