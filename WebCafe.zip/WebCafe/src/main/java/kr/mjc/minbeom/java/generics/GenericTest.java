package kr.mjc.minbeom.java.generics;

public class GenericTest {
    public static void main(String[] args) {
        SimpleBox box = new SimpleBox();
    }
}