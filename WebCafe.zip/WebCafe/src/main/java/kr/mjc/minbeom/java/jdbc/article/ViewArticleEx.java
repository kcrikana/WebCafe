package kr.mjc.minbeom.java.jdbc.article;

public class ViewArticleEx {
    public static void main(String[] args) {
        ArticleDao articleDao = new ArticleDaoImplUsingDbUtils();
        Article article = articleDao.getArticle(1);
        System.out.println(article);
    }
}
