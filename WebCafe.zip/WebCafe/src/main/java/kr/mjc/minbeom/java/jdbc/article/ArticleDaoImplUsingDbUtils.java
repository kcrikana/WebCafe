package kr.mjc.minbeom.java.jdbc.article;

import kr.mjc.minbeom.java.jdbc.DbUtils;
import kr.mjc.minbeom.java.jdbc.ResultSetHandler;
import org.mariadb.jdbc.MariaDbDataSource;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;


public class ArticleDaoImplUsingDbUtils implements ArticleDao {

    private static final String List_Articles
            = "select articleId, title, name from article order by articleId desc limit ?,?";

    private static final String ADD_Articles
            = "insert article(title, userId, content) values(?, ?, ?)";

    private static final String View_Articles
            = "select articleId, name, title, cdate, udate, content from article where articleId=?";

    private static final String Update_Articles
            = "update article set title, content where articledId=?";

    private static final String Delete_Articles
            = "delete from article where articleId=? and userId=?";

    private DbUtils dbUtils;

    ResultSetHandler<Article> h = (rs) -> {
        Article article = new Article();
        article.setArticleId(rs.getInt("articleId"));
        article.setTitle(rs.getString("title"));
        article.setContent(rs.getString("content"));
        return article;
    };


    public ArticleDaoImplUsingDbUtils() {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader()
                .getResourceAsStream("db.properties")) { // 클래스패스에서 읽음
            props.load(in);
            DataSource dataSource = new MariaDbDataSource(
                    props.getProperty("db.url"));
            dbUtils = new DbUtils(dataSource);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




    @Override
    public List<Article> listArticles(int offset, int count) {
        return dbUtils.list(List_Articles, h, offset, count);
    }

    @Override
    public Article getArticle(int articleId) {
        return dbUtils.get(View_Articles, h, articleId);
    }

    @Override
    public void addArticle(Article article) {
        dbUtils
                .update(ADD_Articles, article.getTitle(), article.getContent());
    }

    @Override
    public int updateArticle(Article article) {
        return dbUtils.update(Update_Articles, article.articleId);
    }

    @Override
    public int deleteArticle(int articleId, int userId) {
        return dbUtils.update(Delete_Articles, articleId, userId);
    }


}

