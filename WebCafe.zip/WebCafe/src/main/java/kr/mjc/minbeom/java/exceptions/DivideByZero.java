package kr.mjc.minbeom.java.exceptions;

import java.util.Scanner;

public class DivideByZero {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)){
            System.out.print("나뉨수를 입력하세요 : ");
            int dividend = scanner.nextInt();
            System.out.print("나눗수를 입력하세요 : ");
            int divisor = scanner.nextInt();

            int share = dividend / divisor;
            System.out.format("몫은 %d 입니다.\n", share);
            System.out.println("시스템을 정상 종료합니다.");

        }
    }
}
