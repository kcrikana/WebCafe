package kr.mjc.minbeom.java.lambdaexception;

public interface CheckPerson {
    boolean test(Person p);
}
