package kr.mjc.minbeom.java.lambdaexception;

public interface Greeting {
    void greet();
}
