package kr.mjc.minbeom.java.jdbc.article;

import kr.mjc.minbeom.java.jdbc.DataAccessException;

public class AddArticleEx {
    public static void main(String[] args) {
        ArticleDao articleDao = new ArticleDaoImplUsingDbUtils();
        Article article = new Article();
        article.setTitle("테스트입니다.");
        article.setName("김민범");
        article.setContent("테스트입니다.");
        try {
            articleDao.addArticle(article);
            System.out.format("글을 생성했습니다 : %s\n", article);
        } catch (DataAccessException e) {
            System.err.println(e.getMessage());
        }
    }
}
